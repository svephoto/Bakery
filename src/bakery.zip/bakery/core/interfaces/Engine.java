package bakery.core.interfaces;

public interface Engine {
    void run();
}
